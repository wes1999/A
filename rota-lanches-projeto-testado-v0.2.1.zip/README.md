# Rota Lanches Inteligente — MVP 0.2.1

**Situação: projeto-fonte. A compilação dos APKs e o servidor público são etapas separadas.** Dois apps Android separados e um servidor de sincronização. O projeto foi submetido a testes Node, mas ainda requer build real em Android Studio e validação em dispositivos.

## Estrutura

- `android/Estabelecimento`: aplicativo da loja, com tela WebView para a central.
- `android/Entregador`: aplicativo do motociclista, com tela WebView para sua rota.
- `server`: API Node.js, sem dependências externas de npm.
- `web`: interface responsiva compartilhada, cujo acesso define o papel (loja ou entregador).

## Inicializar servidor para testes

Instale Node.js 20+ e execute:

```bash
cd server
npm install
SHOP_KEY="troque-por-um-segredo-longo" PORT=8080 node server.js
```

No navegador, abra `http://localhost:8080`, digite a mesma chave e configure a loja. **`npm install` é necessário para o servidor renderizar QR Codes reais com a biblioteca `qrcode`.** Cadastre entregadores: cada um terá seu próprio código de acesso. Para o GPS em celulares, **é obrigatório servir o site por HTTPS**. Não exponha publicamente HTTP nem guarde segredos no código.

## Criar APKs no Android Studio

1. Abra `android/Estabelecimento` no Android Studio. Instale Android SDK API 35, Android Gradle Plugin 8.7.3, Gradle compatível e JDK 17.
2. No menu **Build > Build APK(s)**, crie o APK. Repita com `android/Entregador`.
3. Hospede o servidor Node em serviço com HTTPS e **armazenamento persistente** para `DATA_FILE`. Use `SHOP_KEY` secreto.
4. Ao abrir cada APK, insira a URL HTTPS pública do servidor. No APK da loja, entre com `SHOP_KEY`; no de entregador, com código cadastrado pela loja.
5. Para testar o funcionamento por internet, crie a loja com latitude/longitude, cadastre pedidos com coordenadas e pelo menos um entregador, e toque em **Calcular e enviar rotas automaticamente**.

## Novidades na versão 0.2: QR Code e aviso de próxima entrega

1. A loja cadastra o pedido (status **em preparo**) com endereço e coordenadas. Opcionalmente registra WhatsApp do cliente no padrão `+5531999999999` e sua autorização para aviso.
2. Quando o pedido estiver pronto, a loja pressiona **Pedido pronto / gerar QR**. É criado um código aleatório privado por pedido. Ao pressionar **Mostrar QR para retirada**, a central gera a imagem SVG na hora (exige `npm install`).
3. A central despacha os pedidos prontos automaticamente para motoboys. O leitor QR **não escolhe nem altera** quem fará a entrega: somente o motoboy designado poderá confirmar a retirada com seu login. O QR não armazena endereço ou telefone; o servidor resolve os dados usando autenticação.
4. O APK do entregador usa o **Google Code Scanner** (`play-services-code-scanner:16.1.0`) para escanear o código exibido pela loja. Em navegadores de testes há opção de digitar/colar o conteúdo do QR. Requer Google Play Services no aparelho; o módulo de scanner pode precisar de download na primeira utilização.
5. Ao escanear, o entregador recebe a confirmação do pedido, nome, endereço e posição na sua rota. Antes de sair, toca em **Estou indo entregar a [cliente]**. Nesse momento a loja recebe o status **A caminho do cliente**; posteriormente o entregador toca em **Confirmar entrega**. No próximo cliente, repete o botão **Estou indo entregar** e o processo.
6. A central mostra os clientes que já estão **a caminho** e exibe a opção **Avisar cliente pelo WhatsApp** com texto preenchido. **Abrir o WhatsApp não significa que a mensagem foi enviada: o funcionário precisa enviá-la.**
7. **Envio automático opcional**: se forem configurados WhatsApp Business Cloud API e template aprovado, a API tenta enviar a mensagem assim que o entregador inicia o trajeto. Sem credenciais válidas, o status permanece **aguardando aviso manual**.

### Configuração opcional: avisos automáticos pelo WhatsApp

Use variáveis de ambiente no servidor, **não inclua segredos no APK**:

```bash
WHATSAPP_PHONE_NUMBER_ID=seu_phone_number_id
WHATSAPP_ACCESS_TOKEN=seu_access_token
WHATSAPP_TEMPLATE_NAME=pedido_em_rota
WHATSAPP_TEMPLATE_LANG=pt_BR
WHATSAPP_API_VERSION=v24.0
```

Crie e obtenha a aprovação de um template com **dois parâmetros no corpo**: `{{1}}` nome do cliente, `{{2}}` identificador abreviado do pedido. Mensagens iniciadas pelo estabelecimento exigem regras e autorizações do WhatsApp Business; há custos e limites conforme o contrato. Só selecione o consentimento quando realmente houver autorização do cliente. Na falha da API, o estado muda para **falha no envio automático**, permitindo aviso manual. **O envio automático não foi testado contra uma conta WhatsApp real nesta versão**.

## Recursos implementados no código

- Cadastrar loja, entregadores e pedidos; sem quantidade fixa de seis entregas. Pedidos inicialmente ficam **em preparo** e precisam ser marcados prontos antes do despacho.
- Separação de contas por token: cada entregador vê apenas seus pedidos.
- Distribuição automática de pedidos prontos entre entregadores disponíveis.
- Otimização de ordem para até 11 paradas por entregador via programação dinâmica; refinamento 2-opt em rotas maiores.
- Matriz de tempos OSRM para **automóveis** quando disponível (até 70 coordenadas); fallback estimado por distância geográfica quando indisponível ou excedido o limite.
- Rodadas começam e terminam na loja; QR confere a retirada individual; botão para indicar o próximo cliente em rota; confirmação de cada entrega e do retorno; status do motorista.
- Geocodificação opcional pelo Nominatim; selecione o resultado certo e confira o número da casa.
- Compartilhamento GPS **somente enquanto o aplicativo está ativo e o Android permite**; central mostra horário do último GPS.
- Atualização automática das interfaces a cada 12 segundos; navegação externa via Google Maps.
- Persistência simples em arquivo JSON no servidor.

## Limitações importantes / NÃO implementado

- **Não usa roteamento específico de motos nem trânsito em tempo real.** OSRM público tem regras de uso, limite prático, não é SLA. O Google Maps abre `travelmode=driving`; confira a adequação às motos.
- **GPS em segundo plano não está implementado.** Android pode suspender o WebView ao bloquear a tela; exige serviço nativo foreground e notificação persistente em versão futura.
- **Mapa da loja é apenas um ponto de referência**, enquanto os demais dados GPS são exibidos em lista; falta mapa com todos os entregadores, atualização em tempo real e trilhas.
- Ainda não há comprovante de entrega para o cliente, cobrança, integração completa com cozinha, SOS, notificações push, offline, múltiplas filiais nem rastreamento público para clientes. O QR Code de retirada foi acrescentado.
- Arquivo JSON não é adequado a escala/concorrência de produção. Migrar para banco transacional e autenticação robusta.
- Não há controle completo de sessões, redefinição de tokens, trilha de auditoria protegida, limites de uso, antifraude ou regras de retenção de localização. Não usar com dados reais de clientes sem implantar segurança, consentimento e política de privacidade adequados à LGPD.
- O endpoint de geocodificação usa serviço público com política de taxa; para uso comercial, contratar provedor adequado e cache.
- Não existem testes Android instrumentados; comportamento real em dispositivos ainda não validado.

## Testes

```bash
cd server
node --test test.js integration-test.js
```

## Próxima etapa técnica para uma versão de produção

SDK nativo de GPS em serviço foreground (com consentimento), Google Routes ou outro provedor autorizado com perfil motocicleta, banco Postgres, tokens seguros, tela de mapa multi-entregadores, fila de despacho com prioridades e limites por carga, HTTPS, domínio e monitoramento. APIs comerciais precisam de chaves e podem ter custos.

## Compilação por GitHub Actions (alternativa ao Android Studio)

Se os arquivos deste ZIP forem colocados na raiz de **um repositório novo** do GitHub, a ação `.github/workflows/build-apks.yml` permite usar **Actions > Compilar os dois APKs > Run workflow**. Ao terminar a compilação, os dois APKs debug ficam em **Artifacts**. Este workflow está **preparado, mas não foi executado nesta sessão**. Versões debug são para testes, não publicação na Play Store.

## Testes da versão 0.2.1

Os testes Node validam criação, preparo, distribuição, rejeição de QR por entregador não atribuído, leitura do pedido pelo entregador correto, confirmação de saída para cada cliente, visibilidade da loja, impedimento de pular entregas, confirmação individual e retorno. Uma simulação adicional percorre 20 entregas com 3 motoboys, usando matriz de tempos por rua fictícia com vias de mão única, autorização GPS simulada, confirmações, tentativas de fraude e retornos. A otimização de rotas longas agora considera tempos dirigidos na inversão de segmentos. Eles **não** substituem um teste real do leitor Google Play Services em Android, instalação npm do gerador SVG ou entrega de mensagens WhatsApp.


## Realidade dos testes e instalação

- **Teste da lógica:** `cd server && npm test`, sem dados de clientes reais.
- **Teste de interface:** `python tests/browser_smoke.py` requer Chromium/Playwright e acesso do navegador ao `localhost`. Alguns ambientes bloqueiam conexões do navegador por política; isso não significa erro do aplicativo.
- **Teste Android:** é necessário instalar os APKs em Android real ou emulador; câmera QR, GPS com tela bloqueada e WhatsApp real não são verificados pelos testes Node.
- **Uso com várias lojas/entregadores reais:** exige hospedar a API HTTPS, instalar dependências npm, banco persistente, definir credenciais e política de privacidade/LGPD. O APK sozinho não consegue sincronizar os aparelhos.
- **Limitação na distribuição:** o botão de despacho da loja é manual nesta versão; depois de acionado a atribuição é automática. GPS em primeiro plano.
