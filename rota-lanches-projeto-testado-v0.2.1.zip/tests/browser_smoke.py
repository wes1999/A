"""Optional UI smoke test using chromium + Python Playwright; no real Android scanner."""
import os, json, subprocess, tempfile, socket, time
from pathlib import Path
from playwright.sync_api import sync_playwright
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
def freeport():
    s=socket.socket();s.bind(('127.0.0.1',0));p=s.getsockname()[1];s.close();return p
port=freeport()
data_path=Path(tempfile.mkdtemp(prefix='rotalanches-ui-'))/'data.json'
env={**os.environ,'PORT':str(port),'SHOP_KEY':'chave-teste-123','DATA_FILE':str(data_path),'ROUTING_URL':'http://127.0.0.1:9'}
proc=subprocess.Popen(['node','server.js'],cwd=ROOT/'server',env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
base=f'http://127.0.0.1:{port}'
def api(path,data=None,key='chave-teste-123'):
    req=urllib.request.Request(base+'/api'+path,data=None if data is None else json.dumps(data).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST' if data is not None else 'GET')
    with urllib.request.urlopen(req,timeout=10) as r:return json.load(r)
try:
    for _ in range(80):
        try:api('/health');break
        except Exception:time.sleep(.07)
    else:raise RuntimeError('servidor não iniciou')
    api('/shop',{'name':'Lanchonete Simulada','address':'Av. Central, 10','lat':-19.47,'lon':-42.55})
    driver=api('/drivers',{'name':'Motoboy Simulado'})
    o=api('/orders',{'customer':'Cliente A','address':'Rua João, 110','lat':-19.46,'lon':-42.54,'notifyOptIn':False})
    api('/order-ready',{'orderId':o['id']})
    order=api('/state')['orders'][0]
    api('/dispatch',{})
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--no-proxy-server','--proxy-server=direct://','--proxy-bypass-list=*'])
        shop=browser.new_context(viewport={'width':393,'height':851})
        rider=browser.new_context(viewport={'width':393,'height':851},geolocation={'latitude':-19.46,'longitude':-42.54},permissions=['geolocation'])
        errors=[]
        for name,context in [('loja',shop),('entregador',rider)]:
            page=context.new_page(); page.on('pageerror',lambda e, n=name: errors.append(f'{n}: {e}'))
            page.goto(base,wait_until='networkidle')
            page.locator('#token').fill('chave-teste-123' if name=='loja' else driver['token'])
            page.locator('#enter').click()
            page.locator('#dashboard').wait_for(state='visible')
            if name=='loja':
                assert page.locator('#orders').get_by_text('Cliente A').count()==1
                assert page.locator('#orders').get_by_text('Pronto').count()>=1
                loja_page=page
                page.screenshot(path='/mnt/data/rota-lanches-loja-simulacao.png',full_page=True)
            else:
                assert page.locator('#route').get_by_text('Cliente A').count()==1
                page.locator('#gpsStart').click()
                page.wait_for_timeout(900)
                # Simula leitura do QR nativo usando ponte da UI; câmera real não foi testada.
                page.evaluate('(qr) => window.onNativeQrScanned(qr)',order['pickupCode'])
                page.get_by_text('Pedido conferido na retirada').wait_for(timeout=4000)
                page.on('dialog',lambda dialog:dialog.accept())
                page.locator('[data-start]').click()
                page.locator('[data-deliver]').wait_for()
                assert api('/state')['orders'][0]['status']=='a_caminho'
                page.locator('[data-deliver]').click()
                page.get_by_text('Retornar à loja').wait_for()
                page.locator('#returned').click()
                page.get_by_text('Sem rodadas ativas').wait_for()
                page.screenshot(path='/mnt/data/rota-lanches-entregador-simulacao.png',full_page=True)
        assert api('/state')['orders'][0]['status']=='entregue'
        assert api('/state')['drivers'][0]['lastLocation']['lat']==-19.46
        assert not errors,errors
        browser.close()
    print('BROWSER/UI PASS: 2 telas mobile, login loja/motoboy, pedido, QR pela ponte, localização GPS simulada, saída, entrega e retorno; sem erros JavaScript.')
finally:
    proc.terminate()
    try:proc.wait(timeout=3)
    except subprocess.TimeoutExpired:proc.kill()
