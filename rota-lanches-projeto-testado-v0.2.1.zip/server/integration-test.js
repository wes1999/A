const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const {spawn}=require('node:child_process');
test('fluxo QR → retirada → a caminho → loja avisada → entrega → retorno',async()=>{
  const file=path.join(fs.mkdtempSync(path.join(os.tmpdir(),'rotalanches-')),'data.json');const port=20000+Math.floor(Math.random()*10000);
  const child=spawn(process.execPath,['server.js'],{cwd:__dirname,env:{...process.env,DATA_FILE:file,PORT:String(port),SHOP_KEY:'teste-segredo',ROUTING_URL:'http://127.0.0.1:1',WHATSAPP_PHONE_NUMBER_ID:'',WHATSAPP_ACCESS_TOKEN:''}});
  const call=async(p,method='GET',data,t='teste-segredo')=>{const r=await fetch(`http://127.0.0.1:${port}/api${p}`,{method,headers:{Authorization:'Bearer '+t,'Content-Type':'application/json'},body:data?JSON.stringify(data):undefined});return {status:r.status,data:await r.json()};};
  const request=async(...args)=>{const r=await call(...args);if(r.status>=400)throw Error(args[0]+': '+JSON.stringify(r.data));return r.data;};
  try{
    let ready=false;for(let i=0;i<40;i++){try{await request('/health');ready=true;break;}catch{await new Promise(r=>setTimeout(r,70));}}assert.ok(ready,'server did not start');
    await request('/shop','POST',{name:'Loja Teste',address:'Rua A',lat:-19.47,lon:-42.55});
    const d=await request('/drivers','POST',{name:'Moto 1'});
    const d2=await request('/drivers','POST',{name:'Moto 2'});
    await request('/driver/status','POST',{status:'pausa'},d2.token);
    const o1=await request('/orders','POST',{customer:'Pessoa A',address:'Rua B',lat:-19.46,lon:-42.54,customerPhone:'+5531999999999',notifyOptIn:true});
    const o2=await request('/orders','POST',{customer:'Pessoa B',address:'Rua C',lat:-19.48,lon:-42.56});
    assert.equal(o1.status,'preparando');
    assert.equal((await call('/dispatch','POST',{})).status,400,'não despachar pedidos ainda em preparo');
    for(const o of [o1,o2])await request('/order-ready','POST',{orderId:o.id});
    const q=await request('/state');assert.match(q.orders[0].pickupCode,/^RL1:[0-9a-f]{48}$/);
    const code=q.orders[0].pickupCode;
    const r=await request('/dispatch','POST',{});assert.equal(r.rounds.length,1);
    const state=await request('/state','GET',undefined,d.token);assert.equal(state.orders.length,2);
    assert.equal((await call('/scan-pickup','POST',{code},d2.token)).status,400,'entregador não atribuído não pode aceitar QR');
    assert.equal((await call('/start-next','POST',{orderId:r.rounds[0].orderIds[0]},d.token)).status,400,'exige QR da primeira entrega');
    const byId=new Map(q.orders.map(o=>[o.id,o]));
    const ids=r.rounds[0].orderIds;
    // The rider scans every assigned package before starting route.
    for(const id of ids){const sc=await request('/scan-pickup','POST',{code:byId.get(id).pickupCode},d.token);assert.equal(sc.order.id,id);assert.ok(sc.order.address);}
    assert.equal((await request('/scan-pickup','POST',{code},d.token)).ok,true,'releitura do próprio QR é idempotente');
    assert.equal((await call('/deliver','POST',{orderId:ids[0]},d.token)).status,400,'não confirmar sem iniciar trajeto');
    for(const [i,id] of ids.entries()){
      const started=await request('/start-next','POST',{orderId:id},d.token);
      assert.equal(started.ok,true);
      const shop=await request('/state');const current=shop.orders.find(o=>o.id===id);
      assert.equal(current.status,'a_caminho','loja enxerga que o pedido saiu para entrega');
      assert.equal(current.noticeStatus,current.notifyOptIn?'aguardando_aviso_manual':'sem_consentimento_ou_telefone');
      const again=await request('/start-next','POST',{orderId:id},d.token);assert.equal(again.alreadyStarted,true,'não reenviar notificação');
      if(i===0)assert.equal((await call('/start-next','POST',{orderId:ids[1]},d.token)).status,400,'não pode pular entrega');
      await request('/deliver','POST',{orderId:id},d.token);
    }
    const end=await request('/state','GET',undefined,d.token);assert.equal(end.rounds[0].status,'retornando');
    await request('/returned','POST',{},d.token);
    const done=await request('/state','GET',undefined,d.token);
    assert.equal(done.drivers[0].status,'disponivel');assert.equal(done.orders.filter(o=>o.status==='entregue').length,2);
  }finally{child.kill();}
});
