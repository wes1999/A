'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const http=require('node:http');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {plan}=require('./server');

const wait=ms=>new Promise(r=>setTimeout(r,ms));
const createRoadMatrix=points=>points.map((a,i)=>points.map((b,j)=>{
 if(i===j)return 0;
 const km=Math.hypot((a.lat-b.lat)*111,(a.lon-b.lon)*105);
 // Simulates city streets, one-way restrictions and a congested southern access.
 return Math.ceil(90+km*150+(j<i?55:0)+(a.lat<-19.48?120:0));
}));

test('simulação realista: 3 motociclistas, 20 lanches, GPS, QR, 20 clientes, retornos', {timeout:45000},async()=>{
 const data=path.join(fs.mkdtempSync(path.join(os.tmpdir(),'rotalanches-multi-')),'data.json');
 const port=38000+Math.floor(Math.random()*3000), routePort=port+3500;
 const routing=http.createServer((req,res)=>{
   const part=req.url.split('/table/v1/driving/')[1]?.split('?')[0]||'';
   const points=part.split(';').map(coord=>{const [lon,lat]=coord.split(',').map(Number);return {lat,lon}});
   res.writeHead(200,{'Content-Type':'application/json'});
   res.end(JSON.stringify({code:'Ok',durations:createRoadMatrix(points)}));
 });
 await new Promise(resolve=>routing.listen(routePort,'127.0.0.1',resolve));
 const child=spawn(process.execPath,['server.js'],{cwd:__dirname,env:{...process.env,DATA_FILE:data,PORT:String(port),SHOP_KEY:'chave-super-secreta-de-teste',ROUTING_URL:`http://127.0.0.1:${routePort}`,WHATSAPP_PHONE_NUMBER_ID:'',WHATSAPP_ACCESS_TOKEN:''}});
 const call=async(uri,method='GET',data,token='chave-super-secreta-de-teste')=>{
   const res=await fetch(`http://127.0.0.1:${port}/api${uri}`,{method,headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:data?JSON.stringify(data):undefined});
   return {status:res.status,data:await res.json()};
 };
 const ok=async(...args)=>{const r=await call(...args);assert.ok(r.status<400,`${args[0]} ${r.status}: ${JSON.stringify(r.data)}`);return r.data;};
 try {
   let ready=false;
   for(let i=0;i<50;i++){try{await ok('/health');ready=true;break;}catch{await wait(70);}}
   assert.ok(ready,'servidor não inicializado');
   await ok('/shop','POST',{name:'Lanchonete de Teste',address:'Av. Principal, 100',lat:-19.47,lon:-42.55});
   const drivers=[];
   for(let i=0;i<3;i++)drivers.push(await ok('/drivers','POST',{name:`Moto ${i+1}`}));
   const orders=[];
   for(let i=0;i<20;i++){
     const o=await ok('/orders','POST',{customer:`Cliente ${i+1}`,address:`Rua Exemplo, ${100+i}`,lat:-19.47+Math.sin(i*.9)*.034,lon:-42.55+Math.cos(i*.7)*.034,customerPhone:i%3===0?'+5531999999999':'',notifyOptIn:i%3===0});
     orders.push(o);
     await ok('/order-ready','POST',{orderId:o.id});
   }
   assert.equal((await call('/state','GET',undefined,'token-invalido')).status,401,'bloquear não autenticados');
   assert.equal((await call('/driver/location','POST',{lat:100,lon:100},drivers[0].token)).status,400,'GPS inválido rejeitado');
   const res=await ok('/dispatch','POST',{});
   assert.equal(res.method,'vias_osrm_carro');
   assert.equal(res.rounds.length,3);
   const state=await ok('/state');
   const assigned=state.orders.filter(o=>o.assignedDriver);
   assert.equal(assigned.length,20);
   assert.equal(new Set(assigned.map(o=>o.id)).size,20,'sem duplicação de pedidos');
   assert.equal((await call('/dispatch','POST',{})).status,400,'não deve duplicar despacho');
   const orderMap=new Map(state.orders.map(o=>[o.id,o]));
   const assignments=res.rounds.flatMap(r=>r.orderIds.map(orderId=>({orderId,driverId:r.driverId})));
   assert.equal(new Set(assignments.map(a=>a.orderId)).size,20);
   for(const d of drivers){
     await ok('/driver/location','POST',{lat:-19.472,lon:-42.551,accuracy:9},d.token);
     const rider=await ok('/state','GET',undefined,d.token);
     assert.ok(rider.orders.every(o=>o.assignedDriver===d.id),'um entregador não pode ler pedidos de outro');
   }
   for(const r of res.rounds){
     const d=drivers.find(d=>d.id===r.driverId);
     for(const orderId of r.orderIds){
       const o=orderMap.get(orderId);
       const invalid=drivers.find(other=>other.id!==d.id);
       assert.equal((await call('/scan-pickup','POST',{code:o.pickupCode},invalid.token)).status,400,'QR atribuído a outro entregador rejeitado');
       const scanned=await ok('/scan-pickup','POST',{code:o.pickupCode},d.token);
       assert.equal(scanned.order.id,orderId);
     }
     for(const id of r.orderIds){
       const started=await ok('/start-next','POST',{orderId:id},d.token);
       assert.ok(started.ok);
       assert.equal((await ok('/state')).orders.find(o=>o.id===id).status,'a_caminho');
       assert.equal((await ok('/start-next','POST',{orderId:id},d.token)).alreadyStarted,true,'idempotência');
       await ok('/deliver','POST',{orderId:id},d.token);
     }
     const after=await ok('/state','GET',undefined,d.token);
     assert.equal(after.rounds.at(-1).status,'retornando');
     await ok('/returned','POST',{},d.token);
     assert.equal((await ok('/state','GET',undefined,d.token)).drivers[0].status,'disponivel');
   }
   const final=await ok('/state');
   assert.equal(final.orders.filter(o=>o.status==='entregue').length,20);
   assert.equal(final.rounds.filter(r=>r.status==='concluida').length,3);
   assert.ok(final.drivers.every(d=>d.lastLocation?.at));
   assert.ok(final.events.some(e=>e.type==='cliente_em_rota'));
   console.log('SIMULAÇÃO: 20 pedidos, 3 entregadores, 20 QR, 20 saídas, 20 entregas, 3 retornos, GPS e acessos aprovados.');
 }finally{child.kill();routing.close();}
});

test('roteamento com mais de 11 paradas respeita custos dirigidos',()=>{
  const n=18;const points=Array.from({length:n+1},(_,i)=>({lat:-19.47+(i%6)*.001,lon:-42.55+Math.floor(i/6)*.001}));
  const matrix=createRoadMatrix(points);
  const routes=plan(matrix,2,n);
  const visited=routes.flatMap(r=>r.route.slice(1,-1));
  assert.equal(visited.length,n);
  assert.equal(new Set(visited).size,n);
  for(const r of routes){
    const actual=r.route.slice(1).reduce((sum,x,i)=>sum+matrix[r.route[i]][x],0);
    assert.equal(r.timeSeconds,actual,'o tempo final deve usar sentido correto de cada rua');
  }
});
