const {test}=require('node:test');const assert=require('node:assert/strict');const {plan,km}=require('./server');
test('distancia zero',()=>assert.equal(km({lat:-19.47,lon:-42.55},{lat:-19.47,lon:-42.55}),0));
test('rota começa e termina na loja e visita cada pedido',()=>{const m=[[0,3,8,7],[3,0,2,5],[8,2,0,3],[7,5,3,0]];const r=plan(m,2,3);const stops=r.flatMap(x=>x.route.slice(1,-1));assert.deepEqual(stops.sort(),[1,2,3]);assert.ok(r.every(x=>x.route[0]===0&&x.route.at(-1)===0));});
test('zero pedidos e múltiplos entregadores',()=>{const r=plan([[0]],3,0);assert.equal(r.length,3);assert.ok(r.every(x=>x.route.length===2));});
