'use strict';
// Node.js 20+; no npm dependencies. One shop per server deployment for MVP.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const PORT = Number(process.env.PORT || 8080);
const DATA = process.env.DATA_FILE || path.join(__dirname, 'data.json');
const SHOP_KEY = process.env.SHOP_KEY || '';
const PUBLIC_URL = process.env.PUBLIC_URL || '';
const WA_PHONE_ID = process.env.WHATSAPP_PHONE_NUMBER_ID || '';
const WA_TOKEN = process.env.WHATSAPP_ACCESS_TOKEN || '';
const WA_TEMPLATE = process.env.WHATSAPP_TEMPLATE_NAME || '';
const WA_LANG = process.env.WHATSAPP_TEMPLATE_LANG || 'pt_BR';
const WA_API_VERSION = process.env.WHATSAPP_API_VERSION || 'v24.0';
const OSM_ROUTING = process.env.ROUTING_URL || 'https://router.project-osrm.org';
const GEO_URL = process.env.GEOCODING_URL || 'https://nominatim.openstreetmap.org/search';
const uid = () => crypto.randomUUID();
const initial = () => ({shop:{name:'Minha lanchonete',lat:null,lon:null,address:''},drivers:[],orders:[],rounds:[],events:[]});
let db;
try { db=JSON.parse(fs.readFileSync(DATA,'utf8')); } catch { db=initial(); }
function save(){fs.mkdirSync(path.dirname(DATA),{recursive:true});const t=DATA+'.tmp';fs.writeFileSync(t,JSON.stringify(db,null,2));fs.renameSync(t,DATA);}
const send = (res,code,body)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization'});res.end(JSON.stringify(body));};
const error=(res,code,message)=>send(res,code,{error:message});
async function body(req){let s='';for await(const b of req){s+=b;if(s.length>1200000)throw new Error('Payload grande demais');}return s?JSON.parse(s):{};}
function auth(req){const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');if(SHOP_KEY && token===SHOP_KEY)return {role:'shop'};const d=db.drivers.find(x=>crypto.timingSafeEqual(Buffer.from(x.token),Buffer.from(token.padEnd(x.token.length,' ').slice(0,x.token.length)))&&token.length===x.token.length);return d?{role:'driver',driver:d}:null;}
function only(a,role){if(!a||a.role!==role)throw Object.assign(new Error('Acesso negado'),{status:403});}
function validPoint(lat,lon){return typeof lat==='number'&&Number.isFinite(lat)&&lat>=-90&&lat<=90&&typeof lon==='number'&&Number.isFinite(lon)&&lon>=-180&&lon<=180;}
function digest(v){return crypto.createHash('sha256').update(v).digest('hex');}
function statusActive(s){return s==='em_rota'||s==='a_caminho';}
function phoneValid(s){return /^\+[1-9]\d{7,14}$/.test(String(s||''));}
function customerMessage(o){return `Olá, ${o.customer}! Seu pedido da ${db.shop.name} está a caminho. Entrega: ${o.address}.`;}
async function notifyCustomer(o){
  if(!o.notifyOptIn||!phoneValid(o.customerPhone)){o.noticeStatus='sem_consentimento_ou_telefone';save();return;}
  if(!WA_PHONE_ID||!WA_TOKEN||!WA_TEMPLATE){o.noticeStatus='aguardando_aviso_manual';save();return;}
  const ctl=new AbortController();const timeout=setTimeout(()=>ctl.abort(),6500);
  try{
    const r=await fetch(`https://graph.facebook.com/${WA_API_VERSION}/${WA_PHONE_ID}/messages`,{method:'POST',headers:{Authorization:'Bearer '+WA_TOKEN,'Content-Type':'application/json'},signal:ctl.signal,body:JSON.stringify({messaging_product:'whatsapp',to:o.customerPhone.replace(/\D/g,''),type:'template',template:{name:WA_TEMPLATE,language:{code:WA_LANG},components:[{type:'body',parameters:[{type:'text',text:o.customer},{type:'text',text:o.id.slice(0,8)}]}]}})});
    if(!r.ok)throw Error('WhatsApp API respondeu '+r.status);
    o.noticeStatus='enviado_api';o.notifiedAt=new Date().toISOString();event('cliente_avisado_api',{orderId:o.id});
  }catch(e){o.noticeStatus='falha_aviso_automatico';event('falha_notificacao',{orderId:o.id,reason:String(e.message).slice(0,90)});}
  finally{clearTimeout(timeout);save();}
}
function event(type,data){db.events.unshift({id:uid(),type,data,at:new Date().toISOString()});db.events=db.events.slice(0,250);}
const rad=x=>x*Math.PI/180;
function km(a,b){const dlat=rad(a.lat-b.lat),dlon=rad(a.lon-b.lon);const h=Math.sin(dlat/2)**2+Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(dlon/2)**2;return 12742*Math.asin(Math.min(1,Math.sqrt(h)));}
// Estimation fallback is explicitly NOT street routing, traffic, or motorcycle-specific.
async function durations(points){
  const fallback=points.map(a=>points.map(b=>Math.round(km(a,b)/25*3600*1.40)));
  if(points.length>70)return {matrix:fallback,method:'estimativa_geografica'};
  try{
    const coords=points.map(p=>`${p.lon},${p.lat}`).join(';');
    const ctl=new AbortController();const t=setTimeout(()=>ctl.abort(),8500);
    const r=await fetch(`${OSM_ROUTING.replace(/\/$/,'')}/table/v1/driving/${coords}?annotations=duration`,{signal:ctl.signal});clearTimeout(t);
    const j=await r.json();if(!r.ok||j.code!=='Ok'||!j.durations)throw Error('Routing failed');
    return {matrix:j.durations.map((row,i)=>row.map((v,k)=>v==null?fallback[i][k]:v)),method:'vias_osrm_carro'};
  }catch{return {matrix:fallback,method:'estimativa_geografica'};}
}
function plan(matrix,driverCount,orderCount){
  // Multi-depot round trips (same shop) with insertion into the route minimizing makespan.
  const routes=Array.from({length:driverCount},()=>[0,0]);const totals=Array(driverCount).fill(0);
  const undone=Array.from({length:orderCount},(_,i)=>i+1);
  while(undone.length){let best=null;
    for(const stop of undone)for(let k=0;k<routes.length;k++)for(let pos=1;pos<routes[k].length;pos++){
      const a=routes[k][pos-1],b=routes[k][pos];const delta=matrix[a][stop]+matrix[stop][b]-matrix[a][b];
      const projected=Math.max(...totals.map((t,i)=>i===k?t+delta:t));
      const score=projected+0.1*(totals[k]+delta);
      if(!best||score<best.score)best={stop,k,pos,delta,score};
    }
    routes[best.k].splice(best.pos,0,best.stop);totals[best.k]+=best.delta;undone.splice(undone.indexOf(best.stop),1);
  }
  // Exact Held-Karp for <= 11 stops in each rider route; otherwise 2-opt refinement.
  return routes.map((route,k)=>{
    const stops=route.slice(1,-1);
    if(stops.length>=2&&stops.length<=11){
      const n=stops.length, dp=Array.from({length:1<<n},()=>Array(n).fill(Infinity)),prev=Array.from({length:1<<n},()=>Array(n).fill(-1));
      for(let i=0;i<n;i++)dp[1<<i][i]=matrix[0][stops[i]];
      for(let mask=1;mask<(1<<n);mask++)for(let i=0;i<n;i++)if(mask&(1<<i))for(let j=0;j<n;j++)if(!(mask&(1<<j))){const nm=mask|(1<<j),v=dp[mask][i]+matrix[stops[i]][stops[j]];if(v<dp[nm][j]){dp[nm][j]=v;prev[nm][j]=i;}}
      let end=0,min=Infinity,mask=(1<<n)-1;for(let i=0;i<n;i++){let v=dp[mask][i]+matrix[stops[i]][0];if(v<min){min=v;end=i;}}
      const rev=[];while(end>=0){rev.push(stops[end]);const p=prev[mask][end];mask^=1<<end;end=p;}route=[0,...rev.reverse(),0];
    }else if(stops.length>11){
      // Directed 2-opt: changing order also reverses every arc inside the segment.
      // This matters on one-way streets (time A→B can differ from B→A).
      let changed=true,limit=0;
      while(changed&&limit++<8){
        changed=false;
        outer: for(let i=1;i<route.length-2;i++){
          let reversedArcDelta=0;
          for(let j=i+1;j<route.length-1;j++){
            reversedArcDelta+=matrix[route[j]][route[j-1]]-matrix[route[j-1]][route[j]];
            const a=route[i-1],b=route[i],c=route[j],d=route[j+1];
            const delta=matrix[a][c]+matrix[b][d]-matrix[a][b]-matrix[c][d]+reversedArcDelta;
            if(delta< -0.1){route.splice(i,j-i+1,...route.slice(i,j+1).reverse());changed=true;break outer;}
          }
        }
      }
    }
    return {route,timeSeconds:Math.round(route.slice(1).reduce((sum,x,i)=>sum+matrix[route[i]][x],0))};
  });
}
const filetypes={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.webmanifest':'application/manifest+json','.svg':'image/svg+xml'};
async function handle(req,res){
  if(req.method==='OPTIONS')return send(res,200,{});
  const u=new URL(req.url,'http://localhost');
  if(!u.pathname.startsWith('/api/')){
    const filename=path.join(__dirname,'../web',u.pathname==='/'?'index.html':u.pathname);
    const root=path.resolve(__dirname,'../web');if(!path.resolve(filename).startsWith(root+path.sep)&&path.resolve(filename)!==path.join(root,'index.html'))return error(res,403,'Caminho inválido');
    try{const f=fs.readFileSync(filename);res.writeHead(200,{'Content-Type':filetypes[path.extname(filename)]||'application/octet-stream'});return res.end(f);}catch{return error(res,404,'Página não encontrada');}
  }
  if(u.pathname==='/api/health')return send(res,200,{ok:true});
  const a=auth(req);
  if(!a)return error(res,401,'Token inválido. Configure SHOP_KEY no servidor e entre com a chave da loja ou o código do entregador.');
  const data=req.method==='POST'||req.method==='PUT'?await body(req):{};
  if(u.pathname==='/api/me'&&req.method==='GET')return send(res,200,{role:a.role,driver:a.driver?{id:a.driver.id,name:a.driver.name}:null});
  if(u.pathname==='/api/state'&&req.method==='GET'){
    return send(res,200,a.role==='shop'?db:{shop:db.shop,drivers:[{id:a.driver.id,name:a.driver.name,status:a.driver.status}],orders:db.orders.filter(o=>o.assignedDriver===a.driver.id),rounds:db.rounds.filter(r=>r.driverId===a.driver.id)});
  }
  if(u.pathname==='/api/shop'&&req.method==='POST'){
    only(a,'shop');if(!validPoint(data.lat,data.lon)||!String(data.name||'').trim())throw Error('Informe nome, latitude e longitude válidos');
    db.shop={name:String(data.name).slice(0,100),address:String(data.address||'').slice(0,300),lat:data.lat,lon:data.lon};save();return send(res,200,db.shop);
  }
  if(u.pathname==='/api/drivers'&&req.method==='POST'){
    only(a,'shop');if(!String(data.name||'').trim())throw Error('Nome obrigatório');
    const d={id:uid(),name:String(data.name).trim().slice(0,80),token:crypto.randomBytes(18).toString('hex'),status:'disponivel',lastLocation:null};db.drivers.push(d);save();return send(res,201,d);
  }
  if(u.pathname==='/api/driver/status'&&req.method==='POST'){
    only(a,'driver');if(!['disponivel','pausa','offline'].includes(data.status))throw Error('Status inválido');
    const busy=db.rounds.some(r=>r.driverId===a.driver.id&&r.status==='ativa');if(busy&&data.status==='disponivel')throw Error('Conclua primeiro sua rodada');
    a.driver.status=data.status;save();return send(res,200,{status:a.driver.status});
  }
  if(u.pathname==='/api/driver/location'&&req.method==='POST'){
    only(a,'driver');if(!validPoint(data.lat,data.lon))throw Error('GPS inválido');
    a.driver.lastLocation={lat:data.lat,lon:data.lon,accuracy:Number(data.accuracy)||null,at:new Date().toISOString()};save();return send(res,200,{ok:true});
  }
  if(u.pathname==='/api/orders'&&req.method==='POST'){
    only(a,'shop');if(!String(data.address||'').trim()||!validPoint(data.lat,data.lon))throw Error('Endereço e coordenadas obrigatórios');
    const phone=String(data.customerPhone||'').trim();if(phone&&!phoneValid(phone))throw Error('Telefone deve estar em formato internacional, exemplo +5531999999999');
    const o={id:uid(),customer:String(data.customer||'Cliente').slice(0,100),address:String(data.address).slice(0,300),lat:data.lat,lon:data.lon,note:String(data.note||'').slice(0,300),customerPhone:phone,notifyOptIn:Boolean(data.notifyOptIn),noticeStatus:'nao_iniciado',status:'preparando',createdAt:new Date().toISOString(),readyAt:null,pickupCode:null,pickedUpAt:null,startedAt:null,assignedDriver:null,roundId:null,deliveredAt:null};db.orders.push(o);event('pedido_criado',{id:o.id});save();return send(res,201,o);
  }
  if(u.pathname==='/api/order-ready'&&req.method==='POST'){
    only(a,'shop');const o=db.orders.find(x=>x.id===data.orderId);
    if(!o||!['preparando','pronto'].includes(o.status))throw Error('Pedido não está aguardando preparo');
    if(!o.pickupCode)o.pickupCode='RL1:'+crypto.randomBytes(24).toString('hex');
    o.status='pronto';o.readyAt=o.readyAt||new Date().toISOString();event('pedido_pronto_qr',{orderId:o.id});save();
    return send(res,200,{ok:true,id:o.id,status:o.status});
  }
  if(u.pathname==='/api/order-qr'&&req.method==='GET'){
    only(a,'shop');const o=db.orders.find(x=>x.id===u.searchParams.get('id'));
    if(!o||!o.pickupCode)throw Error('Marque o pedido como pronto antes de gerar o QR Code');
    // QR stores only opaque secret, never customer address/phone. The app resolves via authenticated API.
    let QRCode;try{QRCode=require('qrcode');}catch{throw Object.assign(new Error('Instale dependências do servidor: npm install'),{status:503});}
    const svg=await QRCode.toString(o.pickupCode,{type:'svg',margin:3,width:288,errorCorrectionLevel:'M'});
    return send(res,200,{svg,orderId:o.id,customer:o.customer});
  }
  if(u.pathname==='/api/scan-pickup'&&req.method==='POST'){
    only(a,'driver');const raw=String(data.code||'');
    if(!/^RL1:[0-9a-f]{48}$/.test(raw))throw Error('QR Code inválido');
    const o=db.orders.find(x=>x.pickupCode&&x.assignedDriver===a.driver.id&&crypto.timingSafeEqual(Buffer.from(digest(x.pickupCode),'hex'),Buffer.from(digest(raw),'hex')));
    if(!o)throw Error('Este pedido não está atribuído à sua rota ou QR é inválido');
    if(!statusActive(o.status))throw Error('Pedido não está mais em rota');
    if(!o.pickedUpAt){o.pickedUpAt=new Date().toISOString();event('pedido_retirado',{orderId:o.id,driverId:a.driver.id});save();}
    return send(res,200,{ok:true,order:{id:o.id,customer:o.customer,address:o.address,lat:o.lat,lon:o.lon,note:o.note,pickedUpAt:o.pickedUpAt}});
  }
  if(u.pathname==='/api/start-next'&&req.method==='POST'){
    only(a,'driver');const o=db.orders.find(x=>x.id===data.orderId&&x.assignedDriver===a.driver.id);
    if(!o||!statusActive(o.status))throw Error('Pedido não encontrado na rota ativa');
    const r=db.rounds.find(r=>r.id===o.roundId&&r.status==='ativa');if(!r)throw Error('Rodada não está ativa');
    const next=r.orderIds.map(id=>db.orders.find(x=>x.id===id)).find(x=>statusActive(x.status));
    if(next?.id!==o.id)throw Error('Conclua a entrega anterior antes de sair para a próxima');
    if(!o.pickedUpAt)throw Error('Escaneie o QR Code deste pedido na retirada antes de sair');
    if(o.status==='a_caminho')return send(res,200,{ok:true,alreadyStarted:true,noticeStatus:o.noticeStatus});
    o.status='a_caminho';o.startedAt=new Date().toISOString();event('cliente_em_rota',{orderId:o.id,driverId:a.driver.id});save();
    await notifyCustomer(o);
    return send(res,200,{ok:true,noticeStatus:o.noticeStatus,customer:o.customer});
  }
  if(u.pathname==='/api/dispatch'&&req.method==='POST'){
    only(a,'shop');if(!validPoint(db.shop.lat,db.shop.lon))throw Error('Configure a localização da loja');
    const drivers=db.drivers.filter(d=>d.status==='disponivel');const pending=db.orders.filter(o=>o.status==='pronto'&&!o.assignedDriver);
    if(!drivers.length||!pending.length)throw Error('É necessário ter pedidos prontos e entregadores disponíveis');
    if(pending.length>150)throw Error('Distribua em lotes de até 150 pedidos por vez. Não existe limite total de pedidos cadastrados.');
    const points=[db.shop,...pending];const {matrix,method}=await durations(points);const optimized=plan(matrix,drivers.length,pending.length);
    const rounds=[];
    optimized.forEach((p,i)=>{const ids=p.route.slice(1,-1).map(index=>pending[index-1].id);if(!ids.length)return;
      const r={id:uid(),driverId:drivers[i].id,orderIds:ids,status:'ativa',createdAt:new Date().toISOString(),finishedAt:null,estimateSeconds:p.timeSeconds,method};
      for(const id of ids){const o=pending.find(o=>o.id===id);o.assignedDriver=drivers[i].id;o.roundId=r.id;o.status='em_rota';}
      drivers[i].status='em_rota';db.rounds.push(r);rounds.push(r);
    });event('rodadas_criadas',{count:rounds.length,method});save();return send(res,200,{rounds,method,notice:method==='estimativa_geografica'?'Tempos aproximados por distância geográfica, não por ruas.':'Tempos OSRM para automóveis; não específicos de motos, nem trânsito em tempo real.'});
  }
  if(u.pathname==='/api/deliver'&&req.method==='POST'){
    only(a,'driver');const o=db.orders.find(x=>x.id===data.orderId&&x.assignedDriver===a.driver.id);
    if(!o||o.status!=='a_caminho')throw Error('Primeiro marque a entrega como a caminho do cliente');
    const r=db.rounds.find(r=>r.id===o.roundId);const next=r.orderIds.map(id=>db.orders.find(x=>x.id===id)).find(x=>statusActive(x.status));
    if(next?.id!==o.id)throw Error('Confirme a entrega atual antes da próxima');
    o.status='entregue';o.deliveredAt=new Date().toISOString();event('entrega_confirmada',{orderId:o.id,driverId:a.driver.id});
    if(r.orderIds.every(id=>db.orders.find(x=>x.id===id).status==='entregue')){r.status='retornando';a.driver.status='retornando';}
    save();return send(res,200,{ok:true,returning:r.status==='retornando'});
  }
  if(u.pathname==='/api/returned'&&req.method==='POST'){
    only(a,'driver');const r=db.rounds.findLast(r=>r.driverId===a.driver.id&&r.status==='retornando');
    if(!r)throw Error('Nenhuma rodada aguardando retorno');
    // Confirmation by driver, never automatic solely by GPS.
    r.status='concluida';r.finishedAt=new Date().toISOString();a.driver.status='disponivel';event('entregador_retornou',{driverId:a.driver.id});save();return send(res,200,{ok:true});
  }
  if(u.pathname==='/api/geocode'&&req.method==='GET'){
    if(!u.searchParams.get('q')||u.searchParams.get('q').length<5)throw Error('Digite um endereço mais completo');
    const url=new URL(GEO_URL);url.searchParams.set('q',u.searchParams.get('q')+', Brasil');url.searchParams.set('format','json');url.searchParams.set('limit','4');
    const r=await fetch(url,{headers:{'User-Agent':'RotaLanchesMVP/0.1 (local application; contact administrator)'}});
    if(!r.ok)throw Object.assign(new Error('Geocodificação indisponível: tente novamente mais tarde'),{status:502});
    return send(res,200,(await r.json()).map(p=>({display:p.display_name,lat:Number(p.lat),lon:Number(p.lon)})));
  }
  return error(res,404,'Recurso não encontrado');
}
const server=http.createServer((req,res)=>{Promise.resolve(handle(req,res)).catch(e=>{if(!res.headersSent)error(res,e.status||400,e.message||'Erro inesperado');else res.end();});});
if(require.main===module)server.listen(PORT,'0.0.0.0',()=>console.log(`Rota Lanches rodando na porta ${PORT}`));
module.exports={server,plan,km,durations};
