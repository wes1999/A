package br.com.rotalanches;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.net.Uri;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.Toast;

/** WebView client for a separately deployed HTTPS backend. GPS in foreground only. */
public class MainActivity extends Activity {
  private WebView web;
  private static final int LOCATION_REQUEST = 221;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
      requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_REQUEST);
    String url = getPreferences(0).getString("serverUrl", "");
    if(url.isEmpty()) showSetup(); else showWeb(url);
  }
  private void showSetup(){
    LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setPadding(26,45,26,20);
    EditText field=new EditText(this);field.setSingleLine(true);field.setHint("https://seu-servidor.exemplo.com");field.setInputType(17);
    Button go=new Button(this);go.setText("Conectar à central de entregas");
    layout.addView(field);layout.addView(go);setContentView(layout);
    go.setOnClickListener(v->{String u=field.getText().toString().trim();if(!u.startsWith("https://")){Toast.makeText(this,"Use um endereço HTTPS",Toast.LENGTH_LONG).show();return;}
      getPreferences(0).edit().putString("serverUrl",u).apply();showWeb(u);});
  }
  private void showWeb(String url){
    web=new WebView(this);setContentView(web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setGeolocationEnabled(true);
    s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView view,android.webkit.WebResourceRequest request){
      Uri u=request.getUrl();Uri expected=Uri.parse(url);if(!"https".equals(u.getScheme())||!expected.getAuthority().equals(u.getAuthority())){if("https".equals(u.getScheme())||"http".equals(u.getScheme())){try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}}return true;}return false;}});
    web.setWebChromeClient(new WebChromeClient(){@Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback cb){
      boolean allowed=origin.equals(Uri.parse(url).getScheme()+"://"+Uri.parse(url).getAuthority()) && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
      cb.invoke(origin,allowed,false);
    }});
    web.loadUrl(url);
  }
  @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
}
